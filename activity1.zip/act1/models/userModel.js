
import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const User = sequelize.define("User", {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  },
  email: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true
  },
  password: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

export async function insert(data) {
  return await User.create(data);
}

export async function selectAll() {
  return await User.findAll();
}

export async function selectById(id) {
  return await User.findByPk(id);
}

export { sequelize };
