
import { Sequelize } from "sequelize";

export const sequelize = new Sequelize("act1", "root", "", {
  host: "localhost",
  dialect: "mysql",
  logging: false
});
