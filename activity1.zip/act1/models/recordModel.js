
import { DataTypes } from "sequelize";
import { sequelize } from "./db.js";

export const Record = sequelize.define("Record", {
  firstName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  lastName: {
    type: DataTypes.STRING,
    allowNull: false
  },
  age: {
    type: DataTypes.INTEGER,
    allowNull: false
  },
  gender: {
    type: DataTypes.STRING,
    allowNull: false
  },
  type: {
    type: DataTypes.STRING,
    allowNull: false
  },
  hp: {
    type: DataTypes.STRING,
    allowNull: false
  },
  address: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

export async function insert(data) {
  const record = await Record.create(data);
  console.log("Inserted record:", record.toJSON());
  return record;
}

export async function selectAll() {
  return await Record.findAll();
}

export async function selectById(id) {
  return await Record.findByPk(id);
}

export { sequelize };
