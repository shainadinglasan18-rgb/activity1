
import express from "express";
import path from "path";
import session from "express-session";
import flash from "connect-flash";
import router from "./routes/index.js";
import fs from "fs";
import hbs from "hbs";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    name: "connect.sid",
    secret: "xianfire-secret-key-change-this-for-production",
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: 1000 * 60 * 60 * 2
    }
  })
);

app.use(flash());

app.use((req, res, next) => {
  res.locals.success_msg = req.flash("success_msg");
  res.locals.error_msg = req.flash("error_msg");
  next();
});

// Register partials before starting the server
const partialsDir = path.join(__dirname, "views", "partials");

if (fs.existsSync(partialsDir)) {
  const files = fs.readdirSync(partialsDir);

  for (const file of files) {
    if (file.endsWith(".xian")) {
      const partialName = file.replace(/\.xian$/, "");
      const content = fs.readFileSync(
        path.join(partialsDir, file),
        "utf8"
      );

      hbs.registerPartial(partialName, content);
    }
  }
}

app.engine("xian", (filePath, options, callback) => {
  hbs.__express(filePath, options, callback);
});

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "xian");

app.use("/", router);

if (!process.env.ELECTRON) {
  app.listen(PORT, () => {
    console.log(`XianFire running at http://localhost:${PORT}`);
  });
}

export default app;
