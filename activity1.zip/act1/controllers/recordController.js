
import {
  insert,
  selectAll,
  selectById
} from "../models/recordModel.js";

// INSERT: Add a record
export const insertRecord = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const {
      firstName,
      lastName,
      age,
      gender,
      type,
      hp,
      address
    } = req.body;

    if (
      !firstName ||
      !lastName ||
      age === "" ||
      age === undefined ||
      !gender ||
      !type ||
      !hp ||
      !address
    ) {
      return res.status(400).send("Please complete all fields.");
    }

    const numericAge = Number(age);

    if (!Number.isInteger(numericAge) || numericAge < 0) {
      return res.status(400).send("Please enter a valid age.");
    }

    await insert({
      firstName,
      lastName,
      age: numericAge,
      gender,
      type,
      hp,
      address
    });

    res.redirect("/dashboard");
  } catch (error) {
    console.error("Insert error:", error);
    res.status(500).send("Failed to insert record: " + error.message);
  }
};

// ALL: Show all records
export const getAllRecords = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const records = await selectAll();

    res.render("dashboard", {
      title: "CRUD OPERATION",
      records: records.map(record => record.toJSON())
    });
  } catch (error) {
    console.error("Select all error:", error);
    res.status(500).send("Failed to get records: " + error.message);
  }
};

// ONE: Find a record by ID
export const getOneRecord = async (req, res) => {
  if (!req.session.userId) {
    return res.redirect("/login");
  }

  try {
    const id = Number(req.query.id);

    if (!req.query.id || !Number.isInteger(id) || id <= 0) {
      return res.status(400).send(
        'Please enter a valid ID. <a href="/dashboard">Back</a>'
      );
    }

    const record = await selectById(id);

    if (!record) {
      return res.status(404).send(
        'Record not found. <a href="/dashboard">Back</a>'
      );
    }

    res.render("dashboard", {
      title: "CRUD OPERATION",
      records: [record.toJSON()]
    });
  } catch (error) {
    console.error("Select one error:", error);
    res.status(500).send("Failed to find record: " + error.message);
  }
};
