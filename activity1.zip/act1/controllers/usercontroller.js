
import bcrypt from "bcrypt";

import {
  insert,
  selectAll,
  selectById
} from "../models/userModel.js";

// INSERT USER
export const insertUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        message: "Name, email, and password are required"
      });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await insert({
      name,
      email,
      password: hashedPassword
    });

    res.status(201).json({
      message: "User inserted successfully",
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to insert user",
      error: error.message
    });
  }
};

// SELECT ALL USERS
export const getAllUsers = async (req, res) => {
  try {
    const users = await selectAll();

    res.json(
      users.map((user) => ({
        id: user.id,
        name: user.name,
        email: user.email
      }))
    );
  } catch (error) {
    res.status(500).json({
      message: "Failed to get users",
      error: error.message
    });
  }
};

// SELECT ONE USER BY ID
export const getUserById = async (req, res) => {
  try {
    const user = await selectById(req.params.id);

    if (!user) {
      return res.status(404).json({
        message: "User not found"
      });
    }

    res.json({
      id: user.id,
      name: user.name,
      email: user.email
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to get user",
      error: error.message
    });
  }
};
