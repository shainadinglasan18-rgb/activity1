
import bcrypt from "bcrypt";
import { User, sequelize } from "../models/userModel.js";
import { selectAll } from "../models/recordModel.js";

// Make sure database tables exist
await sequelize.sync();

// LOGIN PAGE
export const loginPage = (req, res) => {
  res.render("login", {
    title: "Login"
  });
};

// REGISTER PAGE
export const registerPage = (req, res) => {
  res.render("register", {
    title: "Register"
  });
};

// FORGOT PASSWORD PAGE
export const forgotPasswordPage = (req, res) => {
  res.render("forgotpassword", {
    title: "Forgot Password"
  });
};

// DASHBOARD PAGE
// Displays the table without requiring login
export const dashboardPage = async (req, res) => {
  try {
    const records = await selectAll();

    return res.render("dashboard", {
      title: "CRUD OPERATION",
      records: records.map(record => record.toJSON())
    });
  } catch (error) {
    console.error("Dashboard error:", error);

    return res.status(500).send(
      "Failed to load dashboard: " + error.message
    );
  }
};

// LOGIN FUNCTION
export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = await User.findOne({
      where: { email }
    });

    if (!user) {
      return res.status(401).send(
        "User not found. Check your email."
      );
    }

    const passwordMatch = await bcrypt.compare(
      password,
      user.password
    );

    if (!passwordMatch) {
      return res.status(401).send(
        "Incorrect password."
      );
    }

    req.session.userId = user.id;

    console.log("LOGIN SUCCESS - User ID:", user.id);
    console.log("LOGIN SESSION ID:", req.sessionID);

    req.session.save((error) => {
      if (error) {
        console.error("Session save error:", error);

        return res.status(500).send(
          "Failed to save login session."
        );
      }

      console.log("LOGIN SESSION SAVED:", user.id);

      return res.redirect("/dashboard");
    });
  } catch (error) {
    console.error("Login error:", error);

    return res.status(500).send(
      "Login failed: " + error.message
    );
  }
};

// REGISTER FUNCTION
export const registerUser = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    const existingUser = await User.findOne({
      where: { email }
    });

    if (existingUser) {
      return res.status(409).send(
        "Email is already registered."
      );
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await User.create({
      name,
      email,
      password: hashedPassword
    });

    req.session.userId = user.id;

    req.session.save((error) => {
      if (error) {
        console.error("Session save error:", error);

        return res.status(500).send(
          "Account created, but session could not be saved."
        );
      }

      console.log("REGISTER SUCCESS - User ID:", user.id);

      return res.redirect("/dashboard");
    });
  } catch (error) {
    console.error("Register error:", error);

    return res.status(500).send(
      "Registration failed: " + error.message
    );
  }
};

// LOGOUT FUNCTION
export const logoutUser = (req, res) => {
  req.session.destroy((error) => {
    if (error) {
      console.error("Logout error:", error);

      return res.status(500).send("Logout failed.");
    }

    res.clearCookie("connect.sid");

    return res.redirect("/login");
  });
};
