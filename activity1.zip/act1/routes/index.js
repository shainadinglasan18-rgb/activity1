
import express from "express";

import { homePage } from "../controllers/homeController.js";

import {
  loginPage,
  registerPage,
  forgotPasswordPage,
  dashboardPage,
  loginUser,
  registerUser,
  logoutUser
} from "../controllers/authController.js";

import {
  insertRecord,
  getAllRecords,
  getOneRecord
} from "../controllers/recordController.js";

const router = express.Router();

// Home
router.get("/", homePage);

// Authentication
router.get("/login", loginPage);
router.post("/login", loginUser);

router.get("/register", registerPage);
router.post("/register", registerUser);

router.get("/forgot-password", forgotPasswordPage);
router.get("/logout", logoutUser);

// Dashboard
router.get("/dashboard", dashboardPage);

// Record CRUD
router.post("/records", insertRecord);
router.get("/records", getAllRecords);
router.get("/records/one", getOneRecord);

export default router;
